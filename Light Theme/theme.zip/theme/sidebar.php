
<!-- berita -->
	<section class="berita" id="berita">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<span class="pt-4">Berita</span><hr>
				</div>	
				<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/yj.jpg" width="200px" class="d-block w-100"></div>
			<div class="col-sm-9">
					 <?php if ( is_active_sidebar( 'sidebartop-1' ) ) : ?>  
     					 <div class="sidebartop-1">     
	       				     <?php dynamic_sidebar( 'sidebartop-1' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1-berita">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>  
	       				  </div>
  					    <?php endif; ?>
					<a href="http://localhost/sankita/2019/08/07/hahahahahah/" class="btn btn-dark">view</a>
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/ham.jpg" class="d-block w-100"></div>
			<div class="col-sm-9">
				
					 <?php if ( is_active_sidebar( 'sidebartop-2' ) ) : ?>  
     					 <div class="sidebartop-2">     
	       				     <?php dynamic_sidebar( 'sidebartop-2' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1-berita">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>  
	       				  </div>
  					    <?php endif; ?>
					<a href="#" class="btn btn-dark">view</a>
		
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/rendi.jpg" class="d-block w-100"></div>
			<div class="col-sm-9">
				
					 <?php if ( is_active_sidebar( 'sidebartop-3' ) ) : ?>  
     					 <div class="sidebartop-3">     
	       				     <?php dynamic_sidebar( 'sidebartop-3' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1-berita">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>  
	       				  </div>
  					    <?php endif; ?>
					<a href="#" class="btn btn-dark">view</a>
		
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/rendi.jpg" class="d-block w-100"></div>
			<div class="col-sm-9">
				
					 <?php if ( is_active_sidebar( 'sidebartop-4' ) ) : ?>  
     					 <div class="sidebartop-4">     
	       				     <?php dynamic_sidebar( 'sidebartop-4' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1-berita">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>  
	       				  </div>
  					    <?php endif; ?>
					<a href="#" class="btn btn-dark">view</a>
		
			</div>
			
			
			</div>
		</div>
	</section>
	<!-- end berita-->


<!-- artikel -->
	<section class="artikel" id="artikel">
		<div class="container">
			<div class="row p-2">
				<div class="col-md-12">
					<h5>Artikel</h5><hr>
				</div>
					<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar1' ) ) : ?>  
     					 <div class="sidebar1"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar1' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>

					<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar2' ) ) : ?>  
     					 <div class="sidebar2"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar2' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>


					<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar3' ) ) : ?>  
     					 <div class="sidebar3"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar3' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>

						<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar4' ) ) : ?>  
     					 <div class="sidebar4"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar4' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>


					<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar5' ) ) : ?>  
     					 <div class="sidebar5"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar5' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>


						<div class="col-sm-4">
						 <?php if ( is_active_sidebar( 'sidebar6' ) ) : ?>  
     					 <div class="sidebar6"> 
     					 	<a href="">     
	       				     <?php dynamic_sidebar( 'sidebar6' ); ?>   
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				     </a>  
	       				  </div>

  					    <?php endif; ?>
					</div>


			

				
			
				
			</div>
		</div>
	</section>

	<!-- end-artikel -->