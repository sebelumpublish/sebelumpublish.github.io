<section class="berita" id="berita">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<span class="pt-4">Berita</span><hr>
					
					
				</div>	
				<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/yj.jpg" width="200px" class="d-block w-100"></div>
			<div class="col-sm-9">
						 <?php if ( is_active_sidebar( 'sidebar1' ) ) : ?>  
     					 <div class="sidebar1">     
	       				     <?php dynamic_sidebar( 'sidebar1' ); ?>  
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				  </div>
	       				  </p>
							<a href="#" class="btn btn-dark">view</a>
  						    <?php endif; ?>
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/yj.jpg" width="200px" class="d-block w-100"></div>
			<div class="col-sm-9">
						 <?php if ( is_active_sidebar( 'sidebar1' ) ) : ?>  
     					 <div class="sidebar1">     
	       				     <?php dynamic_sidebar( 'sidebar1' ); ?>  
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				  </div>
	       				  </p>
							<a href="#" class="btn btn-dark">view</a>
  						    <?php endif; ?>
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/yj.jpg" width="200px" class="d-block w-100"></div>
			<div class="col-sm-9">
						 <?php if ( is_active_sidebar( 'sidebar1' ) ) : ?>  
     					 <div class="sidebar1">     
	       				     <?php dynamic_sidebar( 'sidebar1' ); ?>  
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				  </div>
	       				  </p>
							<a href="#" class="btn btn-dark">view</a>
  						    <?php endif; ?>
			</div>
			
			<div class="col-sm-3"><img src="http://localhost/sankita/wp-content/uploads/2019/07/yj.jpg" width="200px" class="d-block w-100"></div>
			<div class="col-sm-9">
						 <?php if ( is_active_sidebar( 'sidebar1' ) ) : ?>  
     					 <div class="sidebar1">     
	       				     <?php dynamic_sidebar( 'sidebar1' ); ?>  
	       				     <p><?php the_widget( 'wp_wdget_text'); ?></p> <div id="postmeta1">Publish on <?php the_time('F jS, Y'); ?> by <?php the_author(); ?></div>
	       				  </div>
	       				  </p>
							<a href="#" class="btn btn-dark">view</a>
  						    <?php endif; ?>
			</div>
			
		
				
			</div>
		</div>
	</section>
	<!-- end berita-->
