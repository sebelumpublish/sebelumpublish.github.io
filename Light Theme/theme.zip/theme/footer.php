<!-- footer -->

	<footer class="footer bg-dark" id="footer">
		<div class="container pt-3">
			<div class="row">
				<div class="col-md-12 m-auto text-center">
					<img src="http://localhost/sankita/wp-content/uploads/2019/07/kj.png" width="70px">
					<p>Kompleks Gua Maria Golo Koe Kelurahan Wae Kelambu <br> Kecamatan Komodo <br>Labuan Bajo<br>Kabupaten Manggarai Barat</p>
				</div>
					
			</div>

		</div>
				
			<div class="container">
				<div class="row">
					<div class="col-md-8 offset-md-2">
							<ul class="nav justify-content-center ">
								<li><img src="http://localhost/sankita/wp-content/uploads/2019/07/wa.png" width="20px"></li>
								<li class="p-1"><p><a href="https://api.whatsapp.com/send?phone=085253288500">085 253 288 500</a></p></li>
								<li class="p-1"><img src="http://localhost/sankita/wp-content/uploads/2019/07/wa.png" width="20px"></li>
								<li class="p-1"><p>+62 812 2747 0391</p></li>
								<li class="p-1"><img src="http://localhost/sankita/wp-content/uploads/2019/07/wa.png" width="20px"></li>
								<li class="p-1"><p>+62 812 3748 1651</p></li>
							</ul>		
					</div>
				</div>	
			</div>

		<div class="container">
			<div class="row">
				<div class="col-md-12 text-center">
					
					<a href="#"><a href="https://web.facebook.com/Yayasan.kitajuga"><img src="http://localhost/sankita/wp-content/uploads/2019/07/f1.png" class="pl-2" width="30px" alt=""></a>
					<a href="#"><a href="https://www.instagram.com/yayasan.kitajuga/"><img src="http://localhost/sankita/wp-content/uploads/2019/07/i1.png"  class="pl-2" width="50px" alt=""></a>
					<a href="#"><a href="https://mail.google.com/mail/u/0/?tab=mm#inbox"><img src="http://localhost/sankita/wp-content/uploads/2019/07/g1.png" class="pl-2" width="30px" alt=""></a>
							
				</div>
			</div>
		</div>
		

		<div class="container ">
				<div class="row text-right">
					<div class="col-md-12">
						

						<div><h6>Sponsor by</h6></div>
						<img src="http://localhost/sankita/wp-content/uploads/2019/07/misereor.jpg" height="50px">
						<img src="http://localhost/sankita/wp-content/uploads/2019/07/llf.jpg">
						<img src="http://localhost/sankita/wp-content/uploads/2019/07/caritas.jpg" width="50px">
					</div>
				</div>	
				<div class="row text-center mt-5">
					<div class="col-md-12">
						<p>&copy 2019 By Yayasan KitaJuga</p>
					</div>
				</div>
		</div>					
	</div>
</footer>
	<!-- end footer -->
 <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<!-- jquery-->
	  <script src="assets/js/jquery-3.4.1.min"></script>
<!--end jquery-->


    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html> 


 